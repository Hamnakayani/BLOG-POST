
const express = require('express');
const router = express.Router();
const postController = require('../controllers/postController');
const { authenticateUser } = require('../middleware/authMiddleware.JS');

router.post('/', authenticateUser, postController.createPost);
router.get('/', postController.getAllPosts);
router.get('/:postId', postController.getPostById);
router.put('/posts/:postId', authenticateUser, postController.updatePost);
router.delete('/posts/:postId', authenticateUser, postController.deletePost);
router.post('/posts/:postId/rate', authenticateUser, postController.ratePost);
router.post('/posts/:postId/comment', authenticateUser, postController.commentOnPost);


module.exports = router;