const express = require('express');
const userInteractionController = require('../controllers/userInteractionController');
const { authenticateUser } = require('../middleware/authMiddleware.JS');
const Post = require('../models/postModel');
const router = express.Router();


router.post('/follow/:userId', authenticateUser, userInteractionController.followUser);
router.delete('/unfollow/:userId', authenticateUser, userInteractionController.unfollowUser);
router.get('/feed', authenticateUser, userInteractionController.getUserFeed);


module.exports = router;
