const express = require('express');
const adminController = require('../controllers/adminController');
const router = express.Router();


router.get('/users', adminController.viewAllUsers);
router.put('/block-user/:userId', adminController.blockUser);
router.get('/blog-posts', adminController.listAllBlogPosts);
router.get('/blog-posts/:postId', adminController.viewBlogPost);
router.put('/disable-blog/:postId', adminController.disableBlog);

module.exports = router;
