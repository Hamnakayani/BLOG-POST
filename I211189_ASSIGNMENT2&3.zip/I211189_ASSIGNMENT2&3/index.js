require('dotenv').config();
const mongoose = require('mongoose');
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json());
const authRoutes = require('./routes/authRoutes');  // AUTH
const postRoutes = require('./routes/postRoutes');  // POST
const postController = require('./controllers/postController');
const userInteractionRoutes = require('./routes/userInteractionRoutes'); // USER INTERACTION
const searchRoutes = require('./routes/searchRoutes'); // SEARCH
const adminRoutes = require('./routes/adminRoutes'); // ADMIN


app.use('/auth', authRoutes);
app.use('/posts', postRoutes);
app.use('/user-interaction', userInteractionRoutes);
app.use('/search', searchRoutes);
app.use('/admin', adminRoutes);

//MONGODB
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error!'));
db.once('open', () => {
  console.log('Connected to MongoDB ! YAYY');
});


app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
