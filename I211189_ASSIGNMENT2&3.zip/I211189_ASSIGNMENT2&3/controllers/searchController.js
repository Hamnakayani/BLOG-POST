
const Post = require('../models/postModel');
const mongoose = require('mongoose');



const searchPosts = async (req, res) => {
    try {
        const { title, content, keywords, categories, authors, sortBy, sortOrder } = req.query;

        const searchQuery = {};
        // BY TITLE
        if (title) {
            searchQuery.title = { $regex: new RegExp(title, 'i') };
        }
        // BY CONTENT
        if (content) {
            searchQuery.content = { $regex: new RegExp(content, 'i') };
        }
        // BY KEYWORDS
        if (keywords) {
            searchQuery.$text = { $search: keywords };
        }
        // BY CATEGORIES
        if (categories) {
            searchQuery.categories = { $in: categories.split(',') };
        }
        // BY AUTHORS
        if (authors) {
            searchQuery.author = { $in: authors.split(',') };
        }

        const searchResults = await Post.find(searchQuery)
            .sort({ [sortBy]: sortOrder === 'desc' ? -1 : 1 })
            .exec();

        res.json(searchResults);
    } catch (error) {
        console.error('Search Error:', error);
        res.status(500).json({ error: 'Server Error!', details: error.message || error });
    }
};

module.exports = { searchPosts };
