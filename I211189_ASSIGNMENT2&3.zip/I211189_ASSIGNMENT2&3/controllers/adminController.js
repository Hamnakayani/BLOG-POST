

const Post = require('../models/postModel');
const User = require('../models/userModel');


//TO VIEW ALL USERS
const viewAllUsers = async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (error) {
        console.error('View All Users Error:', error);
        res.status(500).json({ error: 'Server Error', details: error.message || error });
    }
};


// TO VIEW ALL BLOG POSTS
const listAllBlogPosts = async (req, res) => {
    try {
        const blogPosts = await Post.find();
        const formattedPosts = blogPosts.map(post => ({
            title: post.title,
            author: post.author,
            creationDate: post.createdAt,
            averageRating: calculateAverageRating(post.ratings),
        }));

        res.json(formattedPosts);
    } catch (error) {
        console.error('List All Blog Posts Error:', error);
        res.status(500).json({ error: 'Server Error', details: error.message || error });
    }
};

// TO BLOCK A USER
const blockUser = async (req, res) => {
    try {
        const userIdToBlock = req.params.userId;
        const userToBlock = await User.findById(userIdToBlock);

        if (!userToBlock) {
            return res.status(404).json({ error: 'User not found!' });
        }
        userToBlock.isBlocked = true;
        await userToBlock.save();

        res.json({ message: 'User blocked successfully!' });
    } catch (error) {
        console.error('Block User Error:', error);
        res.status(500).json({ error: 'Server Error', details: error.message || error });
    }
};

// TO VIEW A SPECIFIC BLOG POST
const viewBlogPost = async (req, res) => {
    try {
        const postId = req.params.postId;
        const blogPost = await Post.findById(postId);

        if (!blogPost) {
            return res.status(404).json({ error: 'Blog post not found!' });
        }

        res.json(blogPost);
    } catch (error) {
        console.error('View Blog Post Error!:', error);
        res.status(500).json({ error: 'Server Error', details: error.message || error });
    }
};


// TO DISABLE A BLOG
const disableBlog = async (req, res) => {
    try {
        const postId = req.params.postId;
        const blogPost = await Post.findById(postId);

        if (!blogPost) {
            return res.status(404).json({ error: 'Blog post not found!' });
        }

        // Disable the blog
        blogPost.isDisabled = true;
        await blogPost.save();

        res.json({ message: 'Blog has been disabled successfully!' });
    } catch (error) {
        console.error('Disable Blog Error!:', error);
        res.status(500).json({ error: 'Server Error', details: error.message || error });
    }
};

module.exports = { viewAllUsers,blockUser,listAllBlogPosts,viewBlogPost,disableBlog};
