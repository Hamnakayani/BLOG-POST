
const Post = require('../models/postModel');
const User = require('../models/userModel');


// TO FOLLOW A USER
const followUser = async (req, res) => {
    try {
        const userIdToFollow = req.params.userId;


        const userToFollow = await User.findById(userIdToFollow);
        if (!userToFollow) {
            console.error('User not found:', userIdToFollow);
            return res.status(404).json({ error: 'User not found' });
        }

        // IF ALREADY FOLLOWS
        if (req.user.following.includes(userIdToFollow)) {
            console.error('User is already following this user:', userIdToFollow);
            return res.status(400).json({ error: 'You are already following this user !' });
        }

        req.user.following.push(userIdToFollow);
        await req.user.save();

        res.json({ message: 'User followed successfully!' });
    } catch (error) {
        console.error('Follow User Error!', error);
        res.status(500).json({ error: 'Server Error!', details: error.message || error });
    }
};

// TO UNFOLLOW A USER
const unfollowUser = async (req, res) => {
    try {
        const userIdToUnfollow = req.params.userId;


        req.user.following = req.user.following.filter(id => id !== userIdToUnfollow);
        await req.user.save();

        res.json({ message: 'User has been unfollowed successfully!' });
    } catch (error) {
        console.error('Unfollow User Error!', error);
        res.status(500).json({ error: 'Server Error!', details: error.message || error });
    }
};

// TO VIEW FEED
const getUserFeed = async (req, res) => {
    try {
        // FOLLOWING USERS POSTS
        const userFeed = await Post.find({ author: { $in: req.user.following } });

        res.json(userFeed);
    } catch (error) {
        console.error('Get User Feed Error!', error);
        res.status(500).json({ error: ' Server Error!', details: error.message || error });
    }
};


module.exports = { followUser, unfollowUser, getUserFeed };
