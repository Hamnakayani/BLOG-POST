
const mongoose = require('mongoose');
const Post = require('../models/postModel');





// CREATING A NEW POST
const createPost = async (req, res) => {
    try {
        const { title, content } = req.body;
        const newPost = new Post({
            title,
            content,
            author: req.userId,
        });
        await newPost.save();
        res.status(201).json(newPost);
    } catch (error) {
        console.error('Create Post Error:', error);
        res.status(500).json({ error: 'Internal Server Error', details: error.message || error });
    }
};


//VIEW ALL POSTS
const getAllPosts = async (req, res) => {
    try {
        const posts = await Post.find();
        res.json(posts);
    } catch (error) {
        console.error('Get All Posts Error:', error);
        res.status(500).json({ error: 'Server Error!', details: error.message || error });
    }
};


// VIEWING A POST BY SPECIFIC ID
const getPostById = async (req, res) => {
    try {
        const postId = req.params.postId;

        if (!mongoose.Types.ObjectId.isValid(postId)) {
            return res.status(400).json({ error: 'InCORRECT post ID!' });
        }

        const post = await Post.findById(postId);

        if (!post) {
            return res.status(404).json({ error: 'Post not found!' });
        }

        res.json(post);
    } catch (error) {
        console.error('Get Post By ID Error!', error);
        res.status(500).json({ error: 'Server Error!', details: error.message || error });
    }
};

// UPDATING A POST
const updatePost = async (req, res) => {
    try {
        const postId = req.params.postId;
        const { title, content } = req.body;

        if (!mongoose.Types.ObjectId.isValid(postId)) {
            return res.status(400).json({ error: 'InCORRECT post ID!' });
        }

        const post = await Post.findById(postId);

        if (!post) {
            return res.status(404).json({ error: 'Post not found!' });
        }

        if (post.author.toString() !== req.userId) {
            return res.status(403).json({ error: 'You dont have permission to update this post!' });
        }

        post.title = title;
        post.content = content;
        await post.save();

        res.json(post);
    } catch (error) {
        console.error('Update Post Error!', error);
        res.status(500).json({ error: 'Server Error!', details: error.message || error });
    }
};

// DELETING A POST
const deletePost = async (req, res) => {
    try {
        const postId = req.params.postId;

        if (!mongoose.Types.ObjectId.isValid(postId)) {
            return res.status(400).json({ error: 'InCORRECT post ID' });
        }

        const post = await Post.findById(postId);

        if (!post) {
            return res.status(404).json({ error: 'Post not found!' });
        }

        if (post.author.toString() !== req.userId) {
            return res.status(403).json({ error: 'You dont have permission to delete this post!' });
        }

        await Post.deleteOne({ _id: postId });

        res.json({ message: 'Post has been deleted successfully' });
    } catch (error) {
        console.error('Delete Post Error:', error);
        res.status(500).json({ error: 'Server Error!', details: error.message || error });
    }
};


// COMMENT ON POST
const commentOnPost = async (req, res) => {
    try {
        const postId = req.params.postId;
        const { text } = req.body;


        if (!mongoose.Types.ObjectId.isValid(postId)) {
            return res.status(400).json({ error: 'InCORRECT post ID!' });
        }

        const post = await Post.findById(postId);

        if (!post) {
            return res.status(404).json({ error: 'Post not found!' });
        }

        const newComment = {
            user: req.userId,
            text
        };

        post.comments.push(newComment);
        await post.save();

        res.json(post);
    } catch (error) {
        console.error('Comment on Post Error!', error);
        res.status(500).json({ error: 'Server Error!', details: error.message || error });
    }
};

// RATING A POST
const ratePost = async (req, res) => {
    try {
        const postId = req.params.postId;
        const rating = req.body.rating;


        if (!mongoose.Types.ObjectId.isValid(postId)) {
            return res.status(400).json({ error: 'InCORRECT post ID!' });
        }

        const post = await Post.findById(postId);

        if (!post) {
            return res.status(404).json({ error: 'Post not found!' });
        }

        if (post.ratings.includes(rating)) {
            return res.status(400).json({ error: 'You have already rated this post!' });
        }

        post.ratings.push(rating);
        await post.save();
        res.json(post);
    } catch (error) {
        console.error('Rate Post Error!', error);
        res.status(500).json({ error: 'Server Error!', details: error.message || error });
    }
};


module.exports = { getAllPosts, createPost, getPostById, updatePost, deletePost, ratePost, commentOnPost };


